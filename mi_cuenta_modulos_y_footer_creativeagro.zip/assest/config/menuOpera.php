// Archivo actualizado del menú Operaciones
