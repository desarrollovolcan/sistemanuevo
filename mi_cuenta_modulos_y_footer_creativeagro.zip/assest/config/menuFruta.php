// Archivo actualizado del menú Fruta
