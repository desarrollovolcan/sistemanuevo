// Archivo actualizado del menú Materiales
